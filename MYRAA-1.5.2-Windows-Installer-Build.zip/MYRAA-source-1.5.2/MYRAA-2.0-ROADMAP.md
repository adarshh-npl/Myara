# MYRAA 2.0 implementation roadmap

This upgrade preserves the MYRAA 1.5.2 Electron/React/TypeScript/Python architecture. Keep the original 1.5.2 archive and installer unchanged as the rollback release. Work in a separate Git branch (`feature/myraa-2.0`) and increment the app version only after a tested release candidate.

## Confirmed product requirements

- Smart home starts from zero and uses Home Assistant as the device abstraction layer.
- First device classes: lights, fans, climate/AC, switches/plugs, covers/curtains and read-only sensors.
- Mobile: iPhone first, Android-compatible API contracts later.
- Emergency alerts: initially notify only the paired user's iPhone; no trusted-contact broadcast is enabled.
- Preserve the current desktop companion, Gemini Live bridge, cognition modules, permissions, task engine and Python desktop agent.

## Existing architecture confirmed from source

- `server.ts`: Express server, local-only host/origin guard, Gemini bridge and DPAPI-backed secret store wiring.
- `runtime/myraaRuntime.ts`: owns subsystem construction, initialization and REST route registration.
- `voice/liveAgentTools.ts`: Gemini Live tool declarations and dispatch.
- `permissions/engine.ts`: permission policies and confirmation behavior.
- `settings/appSettings.ts`: versioned, normalized user settings.
- `electron/`: Windows desktop shell.
- `src/`: React interface.

## Implemented in this first source patch

- `integrations/homeAssistant/types.ts`: supported entity and command contracts.
- `integrations/homeAssistant/client.ts`: Home Assistant REST client, URL validation, bearer-token authentication, entity filtering, bounded requests, allowlisted services and state refresh.
- `runtime/myraaRuntime.ts`: initializes the integration and exposes local API routes under `/api/smart-home`.
- `voice/liveAgentTools.ts`: adds device listing and voice control tools. Voice instructions require explicit confirmation before physical changes.
- `integrations/homeAssistant/tests/client.test.ts`: tests URL/token validation, read-only sensors, known-entity restrictions and climate/cover actions.
- `package.json`: `test:smart-home` script.

### Smart-home API

- `GET /api/smart-home/status`
- `GET /api/smart-home/entities?domain=light|switch|fan|climate|cover|sensor`
- `POST /api/smart-home/configure` with `{ "baseUrl": "http://192.168.1.10:8123", "token": "..." }`
- `POST /api/smart-home/refresh`
- `POST /api/smart-home/command` with `{ "command": { ... } }`; the endpoint creates a pending request in MYRAA’s existing confirmation broker and does not execute until explicit approval.

The API is local-only because the existing server rejects non-local Host/Origin requests. Never expose this Express port directly to the internet. The Home Assistant token is passed through MYRAA's existing secret-store callback (DPAPI in the packaged Windows app); only the base URL is written to the app data directory. Plain HTTP is restricted to localhost/private IPv4 addresses; remote Home Assistant URLs must use HTTPS.

Supported actions are deliberately narrow: light/switch/fan on/off; climate set-temperature (10–35°C) and HVAC mode (off/heat/cool/auto); cover open/close/stop. Sensors are read-only. Every action must reference an entity in the latest fetched state list. UI and voice surfaces must obtain explicit confirmation before execution.

## Implementation sequence after this patch

### Phase 1 — Finish desktop smart-home UX

1. Add a Smart Home settings page in `src/` to configure the Home Assistant URL and create/paste a long-lived token without ever displaying it again.
2. Add device discovery, room/group mapping, friendly aliases and scene configuration.
3. Add voice intents for natural-language scenes (Study, Relax, Sleep, Away), with confirmation for initial scene execution and high-impact devices.
4. Add tests for voice confirmation, stale entity lists, disconnected Home Assistant, timeouts and malformed responses.
5. Add rate limits, request audit records, command idempotency and explicit user permission toggles.

### Phase 2 — Intelligence core

1. Inspect and benchmark `models/router.ts`, `cognition/modelRouter.ts`, `cognition/structuredMemory.ts`, `cognition/planner.ts`, `cognition/critic.ts`, `cognition/skillManager.ts`, `agent/planner/stepPlanner.ts` and `agent/loop.ts` before changing behavior.
2. Add task complexity classification and capability-based model routing; use only models/providers the user configured and verify current model IDs before release.
3. Add hybrid keyword + embedding retrieval, memory provenance, confidence and user-controlled deletion/export.
4. Add plan checkpoints, bounded retries, explicit tool-result verification and task outcome evaluations.
5. Build an evaluation suite for factuality, memory recall, tool success, recovery rate, latency and model cost.

### Phase 3 — iPhone app (SwiftUI)

Create `mobile/ios/MYRAA/` with `App/`, `Screens/`, `Services/`, `Security/` and `Models/`. Initial screens: pairing/login, dashboard, voice, smart-home, emergency SOS and settings. Store refresh tokens and device secrets in iOS Keychain. Use APNs for push notifications. Design API contracts to support Android later, but ship iOS first.

### Phase 4 — Remote relay and emergency delivery

Create a separate cloud service, not a public tunnel into the local Express server. Use short-lived device-bound credentials, TLS, signed requests, replay protection, rate limits, revocation, audit logs and APNs. Start with a manual SOS action from the iPhone app and a desktop voice-triggered alert. Emergency alerts initially go only to the paired user's iPhone. A server-side queue should retry APNs delivery and report delivery/acknowledgement separately. Do not claim delivery when APNs has only accepted a request.

### Phase 5 — Release and reliability

1. Build a test Home Assistant instance and simulated entities for every device class.
2. Test device offline, Wi-Fi loss, expired token, duplicate commands, app crash, PC sleep and cloud outage.
3. Test iOS foreground/background push behavior on physical devices.
4. Test emergency flow with non-emergency dry runs and explicit cancellation.
5. Package Windows installer and distribute iOS beta through TestFlight after signing.

## Safety and privacy requirements

- No always-on iPhone microphone assumption: iOS background execution does not permit a general-purpose continuously listening third-party assistant. Use app-open voice, supported shortcuts, notifications and explicit SOS controls.
- Do not claim guaranteed emergency response or replace local emergency services.
- No automatic contacting of other people until the user explicitly configures recipients and approves message templates.
- Do not automate locks, alarms, ovens or other high-impact devices by default. Those need separate risk policy and confirmation.
- Smoke/CO and other life-safety sensors may be surfaced as sensor events, but sensor interpretation and emergency escalation need dedicated safety testing.
- Keep tokens out of logs, UI responses, source files and telemetry.
