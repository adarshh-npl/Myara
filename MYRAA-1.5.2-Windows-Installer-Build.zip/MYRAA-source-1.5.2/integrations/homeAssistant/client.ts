import path from "node:path";
import { readJsonFile, writeJsonFile } from "../../shared/jsonFile";
import type { HomeAssistantCommand, HomeAssistantConfig, HomeAssistantDomain, HomeAssistantState, HomeAssistantSummary } from "./types";

const SUPPORTED_DOMAINS = new Set<HomeAssistantDomain>(["light", "switch", "fan", "climate", "cover", "sensor"]);
const MAX_RESPONSE_BYTES = 2_000_000;

function validateBaseUrl(input: string): string {
  let url: URL;
  try { url = new URL(input); } catch { throw new Error("Enter a valid Home Assistant URL."); }
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Home Assistant must use HTTP or HTTPS.");
  if (url.username || url.password || url.search || url.hash) throw new Error("The Home Assistant URL cannot contain credentials, query parameters or fragments.");
  if (url.protocol === "http:") {
    const host = url.hostname.toLowerCase();
    const local = host === "localhost" || host.endsWith(".local") || host === "127.0.0.1" || host === "::1" ||
      /^10\./.test(host) || /^192\.168\./.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host) || /^169\.254\./.test(host);
    if (!local) throw new Error("For a non-local Home Assistant server, use HTTPS. Plain HTTP is allowed only for local/private network addresses.");
  }
  url.pathname = url.pathname.replace(/\/$/, "");
  return url.toString().replace(/\/$/, "");
}

export class HomeAssistantClient {
  private readonly configFile: string;
  private baseUrl: string | null = null;
  private token: string | null = null;
  private lastError: string | undefined;
  private cachedStates: HomeAssistantState[] = [];
  private connected = false;

  constructor(
    dataDir: string,
    private readonly getSecret: (name: string) => string | undefined,
    private readonly setSecret: (name: string, value: string) => void,
    private readonly fetchImpl: typeof fetch = fetch,
  ) {
    this.configFile = path.join(dataDir, "integrations", "home-assistant.json");
  }

  async initialize(): Promise<void> {
    const saved = await readJsonFile<HomeAssistantConfig | null>(this.configFile, null);
    const configuredUrl = process.env.MYRAA_HOME_ASSISTANT_URL || saved?.baseUrl;
    const configuredToken = process.env.MYRAA_HOME_ASSISTANT_TOKEN || this.getSecret("home_assistant_token");
    if (configuredUrl) this.baseUrl = validateBaseUrl(configuredUrl);
    if (configuredToken) this.token = configuredToken;
    if (this.baseUrl && this.token) {
      try { await this.refreshStates(); } catch (error) { this.lastError = error instanceof Error ? error.message : String(error); }
    }
  }

  async configure(baseUrl: string, token: string): Promise<HomeAssistantSummary> {
    const normalizedUrl = validateBaseUrl(baseUrl.trim());
    const normalizedToken = token.trim();
    if (normalizedToken.length < 20 || normalizedToken.length > 4096) throw new Error("Enter a valid Home Assistant long-lived access token.");
    const previous = { baseUrl: this.baseUrl, token: this.token };
    this.baseUrl = normalizedUrl;
    this.token = normalizedToken;
    try {
      await this.refreshStates();
      this.setSecret("home_assistant_token", normalizedToken);
      await writeJsonFile(this.configFile, { baseUrl: normalizedUrl });
      this.lastError = undefined;
      return this.summary();
    } catch (error) {
      this.baseUrl = previous.baseUrl;
      this.token = previous.token;
      throw error;
    }
  }

  summary(): HomeAssistantSummary {
    const entityCounts: Partial<Record<HomeAssistantDomain, number>> = {};
    for (const state of this.cachedStates) {
      const domain = state.entity_id.split(".")[0] as HomeAssistantDomain;
      if (SUPPORTED_DOMAINS.has(domain)) entityCounts[domain] = (entityCounts[domain] || 0) + 1;
    }
    return { configured: Boolean(this.baseUrl && this.token), connected: this.connected, baseUrl: this.baseUrl, entityCounts, ...(this.lastError ? { lastError: this.lastError } : {}) };
  }

  listEntities(domain?: HomeAssistantDomain): HomeAssistantState[] {
    if (domain && !SUPPORTED_DOMAINS.has(domain)) throw new Error("Unsupported Home Assistant entity domain.");
    return this.cachedStates.filter((state) => {
      const entityDomain = state.entity_id.split(".")[0] as HomeAssistantDomain;
      return SUPPORTED_DOMAINS.has(entityDomain) && (!domain || domain === entityDomain);
    }).map((state) => ({ ...state, attributes: { ...state.attributes } }));
  }

  async refreshStates(): Promise<HomeAssistantState[]> {
    const states = await this.request<HomeAssistantState[]>("/api/states");
    if (!Array.isArray(states)) throw new Error("Home Assistant returned an invalid state list.");
    this.cachedStates = states.filter((state) => state && typeof state.entity_id === "string" && state.attributes && typeof state.attributes === "object");
    this.connected = true;
    this.lastError = undefined;
    return this.listEntities();
  }

  async execute(command: HomeAssistantCommand): Promise<{ ok: true; entityId: string; action: string; state?: HomeAssistantState }> {
    const state = this.cachedStates.find((item) => item.entity_id === command.entityId);
    if (!state) throw new Error("That device is not in the latest Home Assistant state list. Refresh devices and try again.");
    const domain = command.entityId.split(".")[0] as HomeAssistantDomain;
    if (!SUPPORTED_DOMAINS.has(domain) || domain === "sensor") throw new Error("This entity is read-only or unsupported.");

    let service: string;
    let serviceData: Record<string, unknown> = { entity_id: command.entityId };
    if (command.action === "turn_on" || command.action === "turn_off") {
      if (!["light", "switch", "fan"].includes(domain)) throw new Error("Turn on/off is supported only for lights, switches and fans.");
      service = command.action;
    } else if (command.action === "set_temperature") {
      if (domain !== "climate" || !Number.isFinite(command.temperature) || command.temperature < 10 || command.temperature > 35) throw new Error("Temperature must be 10–35°C on a climate entity.");
      service = "set_temperature";
      serviceData.temperature = command.temperature;
    } else if (command.action === "set_hvac_mode") {
      if (domain !== "climate" || !["off", "heat", "cool", "auto"].includes(command.mode)) throw new Error("Unsupported HVAC mode for this climate entity.");
      service = "set_hvac_mode";
      serviceData.hvac_mode = command.mode;
    } else {
      if (domain !== "cover") throw new Error("Cover actions can only be used on a cover entity.");
      service = command.action;
    }

    await this.request(`/api/services/${domain}/${service}`, { method: "POST", body: JSON.stringify(serviceData) });
    const updated = (await this.refreshStates()).find((item) => item.entity_id === command.entityId);
    return { ok: true, entityId: command.entityId, action: command.action, ...(updated ? { state: updated } : {}) };
  }

  private async request<T = unknown>(route: string, init: RequestInit = {}): Promise<T> {
    if (!this.baseUrl || !this.token) throw new Error("Home Assistant is not configured.");
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);
    try {
      const response = await this.fetchImpl(`${this.baseUrl}${route}`, {
        ...init,
        signal: controller.signal,
        headers: { Authorization: `Bearer ${this.token}`, "Content-Type": "application/json", Accept: "application/json", ...init.headers },
      });
      const text = await response.text();
      if (text.length > MAX_RESPONSE_BYTES) throw new Error("Home Assistant response exceeded the size limit.");
      if (!response.ok) throw new Error(`Home Assistant returned HTTP ${response.status}. Check the URL, token and permissions.`);
      return (text ? JSON.parse(text) : undefined) as T;
    } catch (error) {
      this.connected = false;
      this.lastError = error instanceof Error ? error.message : String(error);
      throw error;
    } finally { clearTimeout(timeout); }
  }
}
