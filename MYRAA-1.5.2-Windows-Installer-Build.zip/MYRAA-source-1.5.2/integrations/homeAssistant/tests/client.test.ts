import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { HomeAssistantClient } from "../client";

const states = [
  { entity_id: "light.study", state: "off", attributes: { friendly_name: "Study light" } },
  { entity_id: "fan.bedroom", state: "off", attributes: {} },
  { entity_id: "climate.room", state: "heat", attributes: {} },
  { entity_id: "cover.curtain", state: "closed", attributes: {} },
  { entity_id: "sensor.temperature", state: "24", attributes: {} },
];

async function fixture(fetchImpl: typeof fetch) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), "myraa-ha-"));
  const secrets = new Map<string, string>();
  const client = new HomeAssistantClient(dir, (key) => secrets.get(key), (key, value) => secrets.set(key, value), fetchImpl);
  return { dir, client, secrets };
}

test("requires a valid token and accepts only local HTTP or HTTPS URLs", async () => {
  const { dir, client } = await fixture(async () => new Response(JSON.stringify(states), { status: 200 }));
  await assert.rejects(() => client.configure("http://example.com:8123", "a".repeat(30)), /use HTTPS/);
  await assert.rejects(() => client.configure("http://192.168.1.20:8123", "short"), /valid Home Assistant/);
  await fs.rm(dir, { recursive: true, force: true });
});

test("lists supported entities and refuses unconfirmed or unsafe actions", async () => {
  const calls: string[] = [];
  const fetchImpl: typeof fetch = async (input, init) => {
    const url = String(input);
    calls.push(`${init?.method || "GET"} ${url}`);
    if (url.endsWith("/api/states")) return new Response(JSON.stringify(states), { status: 200 });
    return new Response("[]", { status: 200 });
  };
  const { dir, client } = await fixture(fetchImpl);
  await client.configure("http://192.168.1.20:8123", "x".repeat(40));
  assert.equal(client.listEntities().length, 5);
  assert.equal(client.listEntities("sensor").length, 1);
  await assert.rejects(() => client.execute({ entityId: "sensor.temperature", action: "turn_off" }), /read-only/);
  const result = await client.execute({ entityId: "light.study", action: "turn_on" });
  assert.equal(result.ok, true);
  assert.ok(calls.some((call) => call.includes("/api/services/light/turn_on")));
  await assert.rejects(() => client.execute({ entityId: "light.not_in_registry", action: "turn_on" }), /latest Home Assistant state list/);
  await fs.rm(dir, { recursive: true, force: true });
});

test("only exposes approved climate and cover services", async () => {
  const fetchImpl: typeof fetch = async (input) => String(input).endsWith("/api/states")
    ? new Response(JSON.stringify(states), { status: 200 })
    : new Response("[]", { status: 200 });
  const { dir, client } = await fixture(fetchImpl);
  await client.configure("http://192.168.1.20:8123", "x".repeat(40));
  await client.execute({ entityId: "climate.room", action: "set_temperature", temperature: 22 });
  await client.execute({ entityId: "cover.curtain", action: "open_cover" });
  await assert.rejects(() => client.execute({ entityId: "climate.room", action: "set_temperature", temperature: 50 }), /10–35°C/);
  await fs.rm(dir, { recursive: true, force: true });
});
