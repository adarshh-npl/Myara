export type HomeAssistantDomain = "light" | "switch" | "fan" | "climate" | "cover" | "sensor";

export interface HomeAssistantState {
  entity_id: string;
  state: string;
  attributes: Record<string, unknown>;
  last_changed?: string;
  last_updated?: string;
}

export interface HomeAssistantSummary {
  configured: boolean;
  connected: boolean;
  baseUrl: string | null;
  entityCounts: Partial<Record<HomeAssistantDomain, number>>;
  lastError?: string;
}

export interface HomeAssistantConfig {
  baseUrl: string;
}

export type HomeAssistantCommand =
  | { entityId: string; action: "turn_on" | "turn_off" }
  | { entityId: string; action: "set_temperature"; temperature: number }
  | { entityId: string; action: "set_hvac_mode"; mode: "off" | "heat" | "cool" | "auto" }
  | { entityId: string; action: "open_cover" | "close_cover" | "stop_cover" };
