# MYRAA Smart Home Lab (standalone prototype)

This is an isolated, browser-based prototype for the MYRAA 2.0 smart-home experience. It is intentionally **not integrated into the MYRAA desktop application**.

## Scope and safety

- Does not modify `src/App.tsx`, any existing component, settings, styling, or the 3D character/animation/model files.
- Uses hard-coded simulated devices and sample sensor values only.
- Device toggles and Study/Sleep/Relax/Away scenes change in-memory demo state only. No network requests, Home Assistant calls, appliance commands, alerts, or permission changes are made.
- Added room names are stored in this browser's local storage only.
- This prototype is a UX exploration, not a production integration.

## Run

From this folder, start any static file server, for example:

```bash
python -m http.server 4178
```

Then open `http://localhost:4178` in a browser. Stop the server with Ctrl+C.

## Next integration milestone

Only after explicit approval, the standalone prototype can be adapted into an optional MYRAA module. The existing main interface and 3D character can remain visually and behaviorally unchanged; access could be provided through a separate window or standalone mobile/web client rather than embedding controls into the current companion UI.
