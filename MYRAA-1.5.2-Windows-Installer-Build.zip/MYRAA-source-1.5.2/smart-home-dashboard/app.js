(() => {
  const initialRooms = [
    { id: 'living', name: 'Living Room' }, { id: 'bedroom', name: 'Bedroom' },
    { id: 'study', name: 'Study' }, { id: 'kitchen', name: 'Kitchen' }
  ];
  const devices = [
    {id:'light-living',room:'living',name:'Ceiling lights',type:'light',icon:'💡',on:true,detail:'Main lighting'},
    {id:'plug-tv',room:'living',name:'TV power plug',type:'plug',icon:'🔌',on:false,detail:'Smart plug'},
    {id:'curtain-living',room:'living',name:'Window curtains',type:'curtain',icon:'🪟',on:false,detail:'Cover · closed'},
    {id:'fan-bedroom',room:'bedroom',name:'Bedroom fan',type:'fan',icon:'🌀',on:false,detail:'Ceiling fan'},
    {id:'ac-bedroom',room:'bedroom',name:'Air conditioner',type:'climate',icon:'❄️',on:true,detail:'Cooling · 24°C',value:24},
    {id:'light-bedroom',room:'bedroom',name:'Bedside lamp',type:'light',icon:'🛋️',on:true,detail:'Warm white'},
    {id:'light-study',room:'study',name:'Desk lamp',type:'light',icon:'💡',on:false,detail:'Task lighting'},
    {id:'plug-study',room:'study',name:'Monitor plug',type:'plug',icon:'🔌',on:true,detail:'Smart plug'},
    {id:'sensor-kitchen',room:'kitchen',name:'Air quality monitor',type:'sensor',icon:'🌿',on:false,detail:'Read-only sensor'},
    {id:'light-kitchen',room:'kitchen',name:'Kitchen lights',type:'light',icon:'💡',on:false,detail:'Ceiling lighting'}
  ];
  const scenes = [
    {id:'study',name:'Study',icon:'📚',description:'Focused lighting and quiet'},
    {id:'sleep',name:'Sleep',icon:'🌙',description:'Lights off, room calm'},
    {id:'relax',name:'Relax',icon:'🛋️',description:'Soft evening atmosphere'},
    {id:'away',name:'Away',icon:'🚪',description:'Switch off demo devices'}
  ];
  const state = {rooms:loadRooms(),activeRoom:'all',devices};
  const $ = id => document.getElementById(id);
  function loadRooms(){try{const saved=JSON.parse(localStorage.getItem('myraa-demo-rooms'));return Array.isArray(saved)&&saved.length?saved:initialRooms.map(x=>({...x}));}catch{return initialRooms.map(x=>({...x}));}}
  function saveRooms(){localStorage.setItem('myraa-demo-rooms',JSON.stringify(state.rooms));}
  function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),2200);}
  function renderRooms(){const all=[{id:'all',name:'All rooms'},...state.rooms];$('room-list').innerHTML=all.map(r=>`<button class="room-item ${state.activeRoom===r.id?'active':''}" data-room="${r.id}"><span>${r.id==='all'?'⌂':'⌑'} &nbsp;${escapeHtml(r.name)}</span><small>${r.id==='all'?state.devices.length:state.devices.filter(d=>d.room===r.id).length}</small></button>`).join('');$('room-list').querySelectorAll('[data-room]').forEach(b=>b.addEventListener('click',()=>{state.activeRoom=b.dataset.room;render();}));}
  function renderDevices(){const q=$('device-search').value.trim().toLowerCase();const visible=state.devices.filter(d=>(state.activeRoom==='all'||d.room===state.activeRoom)&&`${d.name} ${d.type} ${d.detail}`.toLowerCase().includes(q));$('room-title').textContent=state.activeRoom==='all'?'All rooms':(state.rooms.find(r=>r.id===state.activeRoom)?.name||'Room');$('device-grid').innerHTML=visible.length?visible.map(d=>`<article class="device-card"><div class="device-top"><div class="device-icon">${d.icon}</div><div><div class="device-name">${escapeHtml(d.name)}</div><div class="device-meta">${escapeHtml(d.detail)}</div></div></div><div class="device-bottom"><span class="state ${d.on?'on':''}">${d.type==='sensor'?'READ ONLY':d.on?'ON':'OFF'}</span>${d.type==='sensor'?'<span class="muted">View sensor</span>':`<button class="toggle" data-device="${d.id}" aria-label="Toggle ${escapeHtml(d.name)}" aria-pressed="${d.on}"><span></span></button>`}</div></article>`).join(''):'<p class="muted">No matching devices in this room.</p>';$('device-grid').querySelectorAll('[data-device]').forEach(b=>b.addEventListener('click',()=>toggleDevice(b.dataset.device)));$('online-count').textContent=state.devices.length;}
  function renderScenes(){$('scene-grid').innerHTML=scenes.map(s=>`<button class="scene-card" data-scene="${s.id}"><span class="scene-icon">${s.icon}</span><span><strong>${s.name}</strong><small>${s.description}</small></span><span class="arrow">›</span></button>`).join('');$('scene-grid').querySelectorAll('[data-scene]').forEach(b=>b.addEventListener('click',()=>applyScene(b.dataset.scene)));}
  function renderSensors(){$('sensor-grid').innerHTML=[['🌡️','24.5°','Temperature'],['💧','48%','Humidity'],['🌫️','18','PM2.5 · µg/m³'],['☀️','320 lx','Ambient light']].map(x=>`<div class="sensor-card"><span class="sensor-icon">${x[0]}</span><div><div class="sensor-value">${x[1]}</div><div class="sensor-label">${x[2]}</div></div></div>`).join('');}
  function toggleDevice(id){const d=state.devices.find(x=>x.id===id);if(!d||d.type==='sensor')return;d.on=!d.on;toast(`${d.name} ${d.on?'turned on':'turned off'} · simulated`);renderDevices();}
  function applyScene(id){const room=state.activeRoom==='all'?null:state.activeRoom;const eligible=state.devices.filter(d=>(!room||d.room===room)&&d.type!=='sensor');const update=(d,on)=>{d.on=on;};if(id==='study'){eligible.forEach(d=>update(d,d.room==='study'&&(['light','plug'].includes(d.type))));}else if(id==='sleep'){eligible.forEach(d=>update(d,d.type==='climate'&&d.room==='bedroom'));}else if(id==='relax'){eligible.forEach(d=>update(d,d.room==='living'&&d.type==='light'));}else if(id==='away'){eligible.forEach(d=>update(d,false));}renderDevices();toast(`${scenes.find(s=>s.id===id).name} scene applied · simulation only`);}
  function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function render(){renderRooms();renderDevices();}
  $('device-search').addEventListener('input',renderDevices);
  $('add-room').addEventListener('click',()=>{$('room-name').value='';$('room-dialog').showModal();$('room-name').focus();});
  $('room-form').addEventListener('submit',e=>{e.preventDefault();const name=$('room-name').value.trim();if(!name)return;const id='room-'+Date.now().toString(36);state.rooms.push({id,name});saveRooms();state.activeRoom=id;$('room-dialog').close();render();toast(`Room “${name}” added`);});
  $('room-form').querySelector('[value="cancel"]').addEventListener('click',()=>$('room-dialog').close());
  renderScenes();renderSensors();render();
})();
